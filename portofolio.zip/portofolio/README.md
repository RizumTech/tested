# Web Resume / PortFolio Template 

Start forward integration. Download update the details as need. Replace resume.pdf with your resume and contact details in contact.js


Live Demo -https://chithakumar13.github.io/
